# 🧬 POGChain - Custom Blockchain for POGs + AI Camera Scanner

POGChain is a custom-built Layer 1 blockchain with NFT minting, a digital marketplace, and AI camera scanning to turn real-world pogs into digital assets.

## Features
- Custom PoA blockchain with POGCOIN
- Built-in NFT support (721 + 1155 behavior)
- On-chain marketplace
- AI scanner with trained TensorFlow model
- Camera recognition of pogs for minting

## Folder Structure
- `chain/` – Genesis config and start scripts
- `scanner/` – AI model + webcam scanner
- `native_token/`, `poglogic/` – custom NFT logic
- `frontend/` – Wallet interface and mint viewer

## Scanner Setup
1. Train model:
```bash
cd scanner/training
python train_model.py
```
2. Run scanner:
```bash
python ../kiosk_scanner.py
```

---

Scan physical pogs → AI detects type → mint NFT → user redeems or returns pog to kiosk.
