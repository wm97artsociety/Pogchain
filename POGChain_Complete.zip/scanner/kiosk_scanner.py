import cv2
import tensorflow as tf
import numpy as np

model = tf.keras.models.load_model("scanner/training/pog_classifier_model")
labels = ['normal', 'cool', 'rare', 'ultra']

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    img = cv2.resize(frame, (224, 224)) / 255.0
    img = np.expand_dims(img, axis=0)
    prediction = model.predict(img)
    label = labels[np.argmax(prediction)]
    confidence = np.max(prediction)

    cv2.putText(frame, f"{label} ({confidence*100:.2f}%)", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("POG Scanner", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
