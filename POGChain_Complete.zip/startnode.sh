#!/bin/bash
geth --datadir ./data init ./chain/genesis.json
geth --networkid 42345 --datadir ./data --http --http.addr 0.0.0.0 --http.api personal,db,eth,net,web3,txpool,miner --mine --miner.threads=1 --unlock 0 --password ./password.txt --allow-insecure-unlock
