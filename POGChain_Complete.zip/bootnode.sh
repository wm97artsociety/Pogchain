#!/bin/bash
bootnode -genkey boot.key && bootnode -nodekey boot.key -verbosity 9 -addr :30301