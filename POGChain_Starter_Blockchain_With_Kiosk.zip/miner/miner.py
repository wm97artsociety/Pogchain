
from core.blockchain import load_chain, save_chain, Block
import time

def mine_block(data):
    chain = load_chain()
    prev_block = chain[-1]
    new_block = Block(
        index=prev_block['index'] + 1,
        timestamp=time.time(),
        data=data,
        previous_hash=prev_block['hash']
    )
    chain.append(new_block.__dict__)
    save_chain(chain)
    print(f"Block #{new_block.index} mined with hash: {new_block.hash}")

# Example mining call:
# mine_block({"type": "mint", "pog": "POG_001", "owner": "wallet123"})
