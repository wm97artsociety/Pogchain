
import json, hashlib, time, os

CHAIN_FILE = "data/chain.json"

class Block:
    def __init__(self, index, timestamp, data, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.compute_hash()

    def compute_hash(self):
        block_string = f"{self.index}{self.timestamp}{self.data}{self.previous_hash}"
        return hashlib.sha256(block_string.encode()).hexdigest()

def create_genesis_block():
    return Block(0, time.time(), {"msg": "POGChain Genesis"}, "0")

def load_chain():
    if os.path.exists(CHAIN_FILE):
        with open(CHAIN_FILE, "r") as f:
            chain = json.load(f)
        return chain
    else:
        genesis = create_genesis_block()
        chain = [genesis.__dict__]
        save_chain(chain)
        return chain

def save_chain(chain):
    with open(CHAIN_FILE, "w") as f:
        json.dump(chain, f, indent=2)
