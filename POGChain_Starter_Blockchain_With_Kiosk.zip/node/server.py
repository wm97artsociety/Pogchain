
from flask import Flask, request
from core.blockchain import load_chain, save_chain, Block
import time

app = Flask(__name__)

@app.route('/mint', methods=['POST'])
def mint():
    data = request.json
    chain = load_chain()
    prev_block = chain[-1]
    new_block = Block(
        index=prev_block['index'] + 1,
        timestamp=time.time(),
        data={"type": "mint", "pog": data["pog"], "owner": data["wallet"]},
        previous_hash=prev_block['hash']
    )
    chain.append(new_block.__dict__)
    save_chain(chain)
    return {"status": "POG minted", "hash": new_block.hash}

if __name__ == '__main__':
    app.run(debug=True, port=5000)
