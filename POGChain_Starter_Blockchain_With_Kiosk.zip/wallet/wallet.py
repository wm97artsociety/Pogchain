
import uuid

def generate_wallet():
    return f"wallet_{uuid.uuid4().hex[:8]}"

# To generate a wallet, run:
# print(generate_wallet())
